Assignment 3: Server Side

1. I believe I have correctly implemented everything. I was not sure whether
you wanted us to clear our database of all the test data, so I left it in
just in case you would want that information. I attempted the reverse 
geolocation by using the geocoder npm package, but I was receiving undefined
addresses, and my guess is that is because I needed a google maps API key.

2. I discussed general principles of this assignment with Sophie Dasinger
and Dorian Pistilli. 

3. I spent approximately 4 hours completing this assignment.