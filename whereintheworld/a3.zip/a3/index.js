var express = require('express');
var mongo = require('mongodb');
var json = require('json');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
/* parser for post body */
var parser = require('body-parser');
var xhr = new XMLHttpRequest();
var app = express();

/* mongodb uri */
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL 
|| 'mongodb://http://arcane-ridge-5647.herokuapp.com/51970/heroku_app31745366';
/* mongodb connection */
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
    db = databaseConnection;
});

app.use(express.static(__dirname + '/public'));
app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());

/* CORS enabling */
app.all('*', function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods',
               'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

/* mainpage get, returns sorted list of all checkins  */
app.get('/', function (req, res) {
    res.set('Content-Type', 'text/html');
    var indexPage = "<!DOCTYPE HTML><html><head><title>Checkins</title>" +
                    "</head><body><h1>Location Checkins</h1>";
  
    db.collection('locations', function (er, collection) {
  	    var cursor = collection.find({});
        var sorted = cursor.sort({ created_at : -1 });
        var array = sorted.toArray (function (err, array) {
            /* iterates through sorted json array and parses data out of json*/
            for (var count = 0; count < array.length; count++) {
                indexPage += "<p>Login: " + array[count].login + " Lat: " + 
                             array[count].lat + " Lng: " + array[count].lng +
                             " Timestamp: " + array[count].created_at + "</p>";
            }
            indexPage += "</body></html>";
            res.send(indexPage);
        });
    });
});

/* returns checkins for a specified user */
app.get('/locations.json', function (req, res) {
    var user = req.query.login;
    /* returns empty json */
    if (user == undefined) {
        res.set('Content-Type', 'application/json');
        res.send([]);
    } else {
        db.collection('locations', function (er, collection) {
            var cursor = collection.find({login : user });
            var sorted = cursor.sort({ created_at : -1 });
            var array = sorted.toArray(function (err, array) {
                res.set('Content-Type', 'application/json');
                res.send(array);
            });
        });
    }
});

/* returns live copy of json at address */
app.get('/redline.json', function (req, res) {
    /* xmlhttprequest package for node.js */
  	xhr.open("GET", "http://developer.mbta.com/lib/rthr/red.json", true);
  	xhr.send();
  	xhr.onreadystatechange = function() {
		    if (xhr.readyState == 4 && xhr.status == 200) {
		  	    res.set('Content-Type', 'application/json');
            /* sends copy of json */
		        res.send(xhr.responseText);
		    }
	  }
});

/* adds new checkin to database and returns last 100 checkins */
app.post('/sendLocation', function (req, res) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    db.collection('locations', function (er, collection) {
        var date = new Date();
        /* current timestamp */
        var dateString = date.toUTCString();
        var characters;
        var login = req.body.login, lat = req.body.lat, lng = req.body.lng;
        /* data to be inserted */
        var toInsert = {
            "login": login,
            "lat": lat,
            "lng": lng,
            "created_at": dateString,
        };
        /* creates json response for post */
        var cursor = collection.find({});
        var sorted = cursor.sort({ created_at : -1 })
        var arary = sorted.limit(100).toArray(function (err, array) {
            characters = {
                "characters": [],
                "students": array,
            };
        });
        /* inserts post into collection so long as all fields are full */
        collection.insert(toInsert, function (err, saved) {
            if (err || login == undefined || lat == undefined ||
                 lng == undefined) {
                res.send(500);
            }
            else {
                res.set('Content-Type', 'application/json');
                res.send(characters);
            }
        });
    });
});

app.listen(process.env.PORT || 5000);